function logIn(){
    const userBox = $("#user-name-input")
    const passwordBox = $("#user-password-input")
    let userOk = false
    let userName = userBox[0].value
    let userPassword = passwordBox[0].value
    $.ajax({
        url: "./json/users.json",
        type: "GET",
        dataType: "json"
    }).done(function(registeredUsers){
        for (let i = 0; i < registeredUsers.length; i++) {
            if(registeredUsers[i].userName == userName && registeredUsers[i].userPassword == userPassword){ 
                localStorage.setItem("currentUser", userName)
                userOk = true;
                headerChange(userName)
                Swal.fire({
                    icon: 'success',
                    title: 'Logueo exitoso!'
                })
                $("#log-in-box").remove()
                let logForm = $("<form id='log-out-box'></form>")
                logForm.addClass("header__log-in")
                $("#header-upper-text").append(logForm[0])
                let btn = $("<input id='log-out-btn'>")
                btn.click(function(){
                    localStorage.removeItem('currentUser')
                    window.location.reload()
                })
                btn.addClass("btn btn-default log-btn")
                btn.attr({type: "submit", value: "Salir"})
                btn.css({"margin-top": "1rem", "margin-bottom": "1rem"})
                $("#log-out-box").append(btn[0])
            }
        }
    }).fail(function(xhr, status, error) {
        console.log(xhr)
        console.log(status)
        console.log(error)
    })
    if(!userOk){
        Swal.fire({
            icon: 'warning',
            title: 'Usuario o Contraseña incorrectos.',
            footer: 'Por favor intenta nuevamente.'
        })
    }
}
//CAMBIA TEXTO DEL ENCABEZADO
function headerChange(text){
    let header = $("#header-user-name")
    header[0].innerText = `${text}!`
}
//KEY EVENT
function enterLog(e){
    if(e.key == "Enter"){
        logIn()
    }
}
function registerWindow(){
    Swal.fire({
        title: 'Por favor ingresa tus datos.',
        html: 
            '<input type="text" id="swal-user-name" class="swal2-input" placeholder="Tu Usuario">' +
            '<input type="password" id="swal-user-password" class="swal2-input" placeholder="Tu Contraseña">' +
            '<input type="text" id="swal-user-trueName" class="swal2-input" placeholder="Tu Nombre">' +
            '<input type="text" id="swal-user-lastName" class="swal2-input" placeholder="Tu Apellido">' +
            '<input type="email" id="swal-user-email" class="swal2-input" placeholder="Correo Electronico">',
        showCancelButton: true,
        preConfirm: () => {
            let swalCheck = false
            if($("#swal-user-name")[0].value.trim() != "" && $("#swal-user-password")[0].value.trim() != "" && $("#swal-user-trueName")[0].value.trim() != "" && $("#swal-user-lastName")[0].value.trim() != "" && $("#swal-user-email")[0].value.trim() != "" && $("#swal-user-name")[0].value.trim() != null && $("#swal-user-password")[0].value != null && $("#swal-user-trueName")[0].value.trim() != null && $("#swal-user-lastName")[0].value.trim() != null && $("#swal-user-email")[0].value.trim() != null){
                let newUser = new Usuario($("#swal-user-name")[0].value, $("#swal-user-password")[0].value, $("#swal-user-trueName")[0].value, $("#swal-user-lastName")[0].value, $("#swal-user-email")[0].value)
                /*userList.push(newUser)*/
                $.ajax({
                    url: "./json/users.json",
                    type: "GET",
                    dataType: "json"
                }).done(function(registeredUsers){
                    registeredUsers.push(JSON.stringify(newUser))
                    swalCheck = true
                    Swal.fire({
                        icon: 'success',
                        title: 'Regitro exitoso!',
                        text: 'Ahora ya puedes loguearte!'
                    })
                }).fail(function(xhr, status, error) {
                    console.log(xhr)
                    console.log(status)
                    console.log(error)
                })
            }
            if(!swalCheck){
                Swal.fire({
                    icon: 'warning',
                    title: 'Usuario o Contraseña incorrectos.',
                    text: 'Por favor comprueba los datos ingresados.'
                })
            }
        }
    })
}

function getSuggestion(){                   
    let chosenGenre = $("#genre-input")[0].value          
    let chosenPlatform = $("#platform-input")[0].value
    let chosenType = $("#type-input")[0].value
    let resultados = []
    $.ajax({
        url: "./json/games.json",
        type: "GET",
        dataType: "json"
    }).done(function(gameArray){
        for (let i = 0; i < gameArray.length; i++) {
            let platformMatch = gameArray[i].platform.indexOf(chosenPlatform) !== -1;
            if(gameArray[i].genre == chosenGenre && gameArray[i].type == chosenType && platformMatch){
                resultados.push(gameArray[i])
            }
        }
        if(resultados.length !== 0){
            buttonSlide("#suggestion-btn")
            const newDiv = $("<div id='result-box'></div>")
            newDiv.css({"color": "honeydew","font-size": "large","margin-top": "1rem", "font-family": "Goldman", "display": "flex", "flex-direction": "column"})
            $("#suggestion-form").append(newDiv[0])
            resultados.forEach(function(element, i, currElem){
                const newTextBox = $(`<p id='result-text${i}'></p>`)
                newTextBox.css({"display": "flex", "flex-direction": "column", "align-items": "center"})
                const newImage = $(`<img src='${currElem[i].coverLink}'>`)
                $("#result-box").append(newTextBox[0])
                $(`#result-text${i}`).append(`Título: ${currElem[i].title} - Año: ${currElem[i].releaseDate}
                - Costo: $${currElem[i].cost}`)
                $(`#result-text${i}`).append(newImage[0])
            })
        }
    }).fail(function(xhr, status, error) {
        console.log(xhr)
        console.log(status)
        console.log(error)
    })
}
function buttonSlide(btn_id){
    $("<input id='reset-btn'>") 
    $("#reset-btn").addClass("btn btn-default log-btn hidden-btn")
    $("#reset-btn").attr({type: "button", value: "Volver a Consultar"})
    $(btn_id).slideUp(500, function(){
        $("#reset-btn").slideDown(500)
    })
}
function resetBtn(id_btn){
    $("#reset-btn").slideUp(500, function(){
        $(id_btn).slideDown(500)
    })
    $("#result-box").remove()
}


