if(localStorage.getItem("currentUser")){
    headerChange(localStorage.getItem("currentUser"))
    $("#log-in-box").remove()
    let logForm = $("<form id='log-out-box'></form>")
    logForm.addClass("header__log-in")
    $("#header-upper-text").append(logForm[0])
    let btn = $("<input id='log-out-btn'>")
    btn.addClass("btn btn-default log-btn")
    btn.attr({type: "submit", value: "Salir"})
    btn.css({"margin-top": "1rem", "margin-bottom": "1rem"})
    $("#log-out-box").append(btn[0])
}
$("#log-in-btn").click(logIn)
$('#log-out-btn').click(function(){
    localStorage.removeItem('currentUser')
    window.location.reload()
})
$("#reg-btn").click(registerWindow)

$("#user-name-input").keypress(enterLog)
$("#user-password-input").keypress(enterLog)

$("#suggestion-btn").click(getSuggestion)
$("#reset-btn").click(function(){
    resetBtn("#suggestion-btn")
})
$("#dota-submit-btn").click(dotaCall)

