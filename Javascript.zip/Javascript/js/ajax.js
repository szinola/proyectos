function dotaCall(){
    $.ajax({
        url: "https://api.opendota.com/api/heroes",
        type: "GET",
        dataType: "json"
    }).done(function(heroArray){
        const attackType = $("#dota-atk-input")[0].value
        const attributeType = $("#dota-primary-input")[0].value
        const roleType = $("#dota-role-input")[0].value
        let resultArray = []
        for (let i = 0; i < heroArray.length; i++) {
            const chosenRole = heroArray[i].roles.indexOf(roleType) !== -1
            if(attackType == heroArray[i].attack_type && attributeType == heroArray[i].primary_attr && chosenRole){
                resultArray.push(heroArray[i].localized_name)
            }
        }
        if(resultArray.length != 0){
            Swal.fire({
                icon: 'success',
                title: `Tus heroes recomendados son: `,
                text: `${resultArray.join(", ")}`
            })
        }
    }).fail(function(xhr, status, error) {
        console.log(xhr)
        console.log(status)
        console.log(error)
    })  
}
