//Constructor de Juegos
class Game{
    constructor(title, releaseYear, genre, platform, type, cost, link){
        this.title = title
        this.releaseDate = releaseYear
        this.genre = genre
        this.platform = platform
        this.type = type
        this.cost = cost
        this.coverLink = link
        this.printData = function(){
            console.log("Title: " + this.title + " - Release Date: " + this.releaseYear + " - Genre: " + this.genre + " - Plataforma: " + this.platform + " - Precio: $" + this.cost)
        }
    }
}

let theLastofUs = new Game('The Last of Us', 2013, 'accion', ['playstation'], 'modern', 3000, 'https://uvejuegos.com/img/caratulas/53086/TLOU.jpg')
let tombRaider = new Game('Tomb Raider', 2013, 'accion', ['playstation', 'pc'], 'modern', 800, 'https://uvejuegos.com/img/caratulas/43134/Capturaii.JPG')
let residentEvil4 = new Game('Resident Evil 4', 2005, 'accion', ['playstation', 'pc', 'switch'], 'classic', 800, 'https://uvejuegos.com/img/caratulas/61804/Resident-Evil-4-Switch-EU.jpg')

let oriBindForest = new Game('Ori and the Blind Forest', 2015, 'platformer', ['pc', 'switch'], 'modern', 600, 'https://uvejuegos.com/img/caratulas/54827/ori-2.jpg')
let hollowKnight = new Game('Hollow Knight', 2017, 'platformer', ['pc', 'switch', 'playstation'], 'modern', 700, 'https://uvejuegos.com/img/caratulas/57216/hollow-knight-cover.jpg')
let shovelKnight = new Game('Shovel Knight: Treasure Trove', 2014, 'platformer', ['pc', 'switch', 'playstation'], 'classic', 500, 'https://uvejuegos.com/img/caratulas/51735/Captura.JPG')

let starcraft2 = new Game('Starcraft 2', 2010, 'strategy', ['pc'], 'modern', 2000, 'https://uvejuegos.com/img/caratulas/25820/porteuscii.jpg')
let civilizationVI = new Game('Civilization VI', 2016, 'strategy', ['pc'], 'modern', 500)
let ageOfEmpiresDef = new Game('Ago of Empire 2: Definite Edition', 2019, 'strategy', ['pc'], 'classic', 400, 'https://uvejuegos.com/img/caratulas/56720/sid-meiers-civilization-vi-cover.jpg')

let dBFighterz = new Game('Dragon Ball FighterZ', 2018, 'fight', ['pc', 'playstation', 'switch'], 'classic', 1000, 'https://uvejuegos.com/img/caratulas/59233/Dragon-Ball-FighterZ-PC.jpg')
let mortalKombat11 = new Game('Mortal Kombat 11', 2019, 'fight', ['pc', 'playstation'], 'classic', 1500, 'https://uvejuegos.com/img/caratulas/62008/Mortal-Kombat-11-Switch-EU.jpg')


let trailsColdSteel = new Game('Trails if Cold Steel', 2015, 'rpg', ['pc', 'playstation', 'switch'], 'modern', 500, 'https://uvejuegos.com/img/caratulas/62526/The-Legend-of-Heroes-Trails-of-Cold-Steel-Cover.jpg')
let trailsinTheSky = new Game('Trails in the Sky', 2005, 'rpg', ['pc', 'playstation', 'switch'], 'classic', 450, 'https://uvejuegos.com/img/caratulas/58666/legend.jpg')
let dragonQuest11 = new Game('Dragon Quest XI', 2018, 'rpg', ['pc', 'playstation', 'switch'], 'modern', 800, 'https://uvejuegos.com/img/caratulas/60753/DQXI_PC-2D-ES-packshot_1528736537.jpg')


let residentEvil2Rem = new Game('Resident Evil 2 Remake', 2019, 'horror', ['pc', 'playstation'], 'modern', 800, 'https://uvejuegos.com/img/caratulas/57232/resident-evil-2-remake-EU-PC.jpg')
let residentEvilRevelation = new Game('Resident Evil Revelations: Complete Edition', 2015, 'horror', ['pc', 'playstation', 'switch'], 'classic', 800, 'https://uvejuegos.com/img/caratulas/50661/Captura.jpg')

let games = [theLastofUs, tombRaider, residentEvil4, oriBindForest, hollowKnight,shovelKnight,starcraft2, civilizationVI, ageOfEmpiresDef, dBFighterz, mortalKombat11, trailsColdSteel, trailsinTheSky, dragonQuest11, residentEvil2Rem, residentEvilRevelation]


// Constructor de Usuarios
class Usuario{                                  
    constructor(uName, uPassword, uTrueName, uTrueLastName, uEmail){
        this.userName = checkData(uName)
        this.userPassword = checkData(uPassword)
        this.userTrueName = checkData(uTrueName)
        this.userTrueLastName = checkData(uTrueLastName)
        this.userEmail = checkData(uEmail)
        function checkData(data){
            if(data == "" || data == null){
                return null
            }else{
                return data
            }
        }
    }
}

let prueba = new Usuario('asd', 'asd', 'Prueba', 'Prueba', 'asd@asd.com')
let juanMarchi = new Usuario('Juampa87', 'juan1234', 'Juan Pablo', 'Marchi', 'juampamarchi@gmail.com')
let pedroGomez = new Usuario('Pepe_G', 'pep2020', 'Pedro', 'Gomez', 'pepe_gomez@gmail.com')
let eduPerez = new Usuario('EddieRock', 'edupe1990', 'Eduardo', 'Perez', 'juampamarchi@gmail.com')
let sofiLopez = new Usuario('Sophie__', 'soflop1010', 'Sofia', 'Lopez', 'sophie_lop@gmail.com')

let userList = [prueba, juanMarchi, pedroGomez, eduPerez, sofiLopez]
